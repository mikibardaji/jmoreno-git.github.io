<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8"/>
        <title>Form</title>
        <link rel="stylesheet" type="text/css" href="form.css" />
        <style>
            label {display: block;}
            span.error {color:red; font-size: small;}
        </style>
    </head>
    <body>
        <?php
        require_once "fn_sanitize.php";

        use proven\sanitize as sanitize;

        //define sanitize filters.
        $sanitizeFilters = [
            'age' => FILTER_SANITIZE_NUMBER_INT,
            'name' => [
                'filter' => FILTER_SANITIZE_STRING,
                'flags' => FILTER_FLAG_STRIP_LOW | FILTER_FLAG_ENCODE_HIGH
            ],
            'email' => FILTER_SANITIZE_EMAIL,
            'homepage' => FILTER_SANITIZE_URL,
            'message' => [
                'filter' => FILTER_SANITIZE_STRING,
                'flags' => FILTER_FLAG_ENCODE_LOW | FILTER_FLAG_ENCODE_HIGH
            ],
        ];
        //define validation filters.
        $validationFilters = [
            'age' => [
                'filter' => FILTER_VALIDATE_INT,
                'options' => ['min_range' => 0, 'max_range' => 120]
               ],
            'name' => [
                'filter' => FILTER_VALIDATE_REGEXP,
                'options' => ['regexp' => "/^[a-zA-Z]+[\s|-]?[a-zA-Z]+[\s|-]?[a-zA-Z]+$/"]
                //'options' => ['regexp' => "/^\pL[\pL '-]*\z/"]
            ],
            'email' => FILTER_VALIDATE_EMAIL,
            'homepage' => FILTER_VALIDATE_URL,
            'message' => FILTER_DEFAULT
        ];
        //array to hold data after validation
        $validatedInput = array();
        //array to hold validation errors
        $validationErrors = array();
        //check that form has been submitted
        if (\filter_input(\INPUT_POST, 'send')) {
            //get sanitized and validated input data.
            $validatedInput = sanitize\sanitizeAndValidate(
                    $_POST,
                    $sanitizeFilters,
                    $validationFilters);
            //fill error array.
            if ($validatedInput) {
                $validationErrors = sanitize\getErrors($validatedInput);
            }
        }
        //var_dump($validatedInput);
        ?>

        <form method="post" action="<?php \htmlspecialchars($_SERVER['PHP_SELF'], ENT_QUOTES) ?>">
            <fieldset>
                <legend>Personal form</legend>
                <div>
                    <label>Name:</label>
                    <input type="text" name="name" value="<?php echo ($validatedInput['name'] ?? ""); ?>" size="50" />
                    <span class='error'><?php echo $validationErrors['name'] ?? ""; ?></span>
                </div>
                <div>
                    <label>Age:</label>
                    <input type="text" name="age" value="<?php echo $validatedInput['age'] ?? ""; ?>" size="50" />
                    <span class='error'><?php echo $validationErrors['age'] ?? ""; ?></span>
                </div>
                <div>
                    <label>Email Address:</label>
                    <input type="text" name="email" value="<?php echo $validatedInput['email'] ?? ""; ?>" size="50" />
                    <span class='error'><?php echo $validationErrors['email'] ?? ""; ?></span>
                </div>
                <div>
                    <label>Home Page:</label>
                    <input type="text" name="homepage" value="<?php echo $validatedInput['homepage'] ?? ""; ?>" size="50" />
                    <span class='error'><?php echo $validationErrors['homepage'] ?? ""; ?></span>
                </div>
                <div>
                    <label>Message:</label>
                    <textarea name="message" rows="5" cols="50"><?php echo $validatedInput['message'] ?? ""; ?></textarea>
                    <span class='error'><?php echo $validationErrors['message'] ?? ""; ?></span>
                </div>
                <div>
                    <input type="submit" name="send" />
                </div>
            </fieldset>
        </form>
    </body>
</html>

