<?php
namespace proven\sanitize;
/**
 * sanitizes and validates data agains given filters
 * @param array $data data to sanitize and validate
 * @param array $sanitizeFilters filters to sanitize
 * @param array $validationFilters filters to validate
 * @return array data after sanitizing and validation
 */
function sanitizeAndValidate(
        array $data, 
        array $sanitizeFilters, 
        array $validationFilters
    ): array {
    //trim input data (strip spaces)
    $trimmedData = \array_map('trim', $data);
    //sanitize input data 
    $sanitizedData = \filter_var_array(
            $trimmedData,
            $sanitizeFilters,
            true
    );
    //validate input data
    $validatedData = \filter_var_array(
            $sanitizedData,
            $validationFilters,
            true
    );
    //var_dump($validatedData);
    return $validatedData;
}

/**
 * parses data and build array of errors
 * @param array $data data to parse 
 * @return array errors in data
 */
function getErrors(array $data): array {
    $errors = array();
    if (!is_null($data)) {
        foreach ($data as $key => $value) {
            if ($value === null) {
                $errors[$key] = "Missing field";
            } else {
                if ($value === false) {
                    $errors[$key] = "Invalid value";
                } else {
                    $errors[$key] = "";
                }
            }
        }
    }
    return $errors;
}
