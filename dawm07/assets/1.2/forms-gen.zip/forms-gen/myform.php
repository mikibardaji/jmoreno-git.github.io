<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Forms example</title>
    <link href="css/styles.css" rel="stylesheet" type="text/css" />
  </head>
  <body>
    <h2>Forms example</h2>
    <?php
      include "php-fn/forms-fn.php";
      use proven\forms as forms;
      //data to configure form
      $formData = array(
        'method' => 'get',
        'action' => $_SERVER['PHP_SELF'],
        'fields' => array(
          'name' => 'Peter',
          'age' => 20
        )
      );
      echo forms\createForm($formData);
    ?>
  </body>
</html>
