<?php
namespace proven\forms {

  /**
  * creates html code for a form
  * @param $action the action of the form
  * @param $method the method of the form
  * @param $fields the fields of the form
  * @return form code
  */
  function createForm($formData) {
      $ret = "";
      $ret .= sprintf("<form action='%s' method='%s'>", $formData['action'], $formData['method']);
      foreach($formData['fields'] as $name => $value) {
          $ret .= sprintf("\n<label>%s: </label>", $name);
          $ret .= sprintf("<input type='text' name='%s' value='%s' />", $name, $value);
      }
      $ret .= sprintf("\n<button type='submit'>submit</button>");
      $ret .= "\n</form>";
      return $ret;
  }

} //end namespace
