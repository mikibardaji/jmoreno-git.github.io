<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8"/>
		<title>Form</title>
		<link rel="stylesheet" type="text/css" href="form.css" />
		<style>
			.error {color:red; font-size: small;};
		</style>
	</head>
	<body>
		<?php
		require "input_sanitize.php";
		//retrieve input data and sanitize/validate.
		$sanitizedPost = filter_input_array(
			INPUT_POST,
			array(
				'send' => FILTER_SANITIZE_STRING,
				'age' => array(
					'filter' => FILTER_VALIDATE_INT,
					'options' => array('min_range' => 0, 'max_range' => 120)
				),
				'name' => FILTER_SANITIZE_STRING,
				'email' => FILTER_VALIDATE_EMAIL,
				'homepage' => FILTER_VALIDATE_URL,
				'message' => FILTER_SANITIZE_STRING,
			),
			true
		);
		//fill error array.
		if ($sanitizedPost) $postErrors = \proven\sanitize\getErrors($sanitizedPost);
//			var_dump($sanitizedPost);
//			var_dump($postErrors);
		?>
	
		<form method="post" action="<?php $_SERVER['PHP_SELF']?>">
			<fieldset>Personal data form
				<p>
					<label>Name:</label>
					<input type="text" name="name" value="<?php echo $sanitizedPost['name']; ?>" size="50" />
					<span class='error'><?php if (isset($postErrors['name'])) echo $postErrors['name']; ?></span>
				</p>
				<p>
					<label>Age:</label>
					<input type="text" name="age" value="<?php echo $sanitizedPost['age']; ?>" size="50" />
					<span class='error'><?php if (isset($postErrors['age'])) echo $postErrors['age']; ?></span>
				</p>
				<p>
					<label>Email Address:</label>
					<input type="text" name="email" value="<?php echo $sanitizedPost['email']; ?>" size="50" />
					<span class='error'><?php if (isset($postErrors['email'])) echo $postErrors['email']; ?></span>
				</p>
				<p>
					<label>Home Page:</label>
					<input type="text" name="homepage" value="<?php echo $sanitizedPost['homepage']; ?>" size="50" />
					<span class='error'><?php if (isset($postErrors['homepage'])) echo $postErrors['homepage']; ?></span>
				</p>
				<p>
					<label>Message:</label>
					<textarea name="message" rows="5" cols="50"><?php echo $sanitizedPost['message']; ?></textarea>
					<span class='error'><?php if (isset($postErrors['message'])) echo $postErrors['message']; ?></span>
				</p>
				<p>
					<input type="submit" name="send" />
				</p>
			</fieldset>
		</form>
	</body>
</html>
