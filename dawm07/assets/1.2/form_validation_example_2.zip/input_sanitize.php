<?php
namespace proven\sanitize;
function getErrors(array $data): array {
    $errors = array();
    if (!is_null($data)) {
        foreach ($data as $key => $value) {
            if ($value===null) {
                $errors[$key] = "nullValueError";
            }
            else {
                if ($value===false) {
                    $errors[$key] = "falseValueError";
                } else {
                    $errors[$key] = "";
                }
            }
        }
    }
    return $errors;
}
?>