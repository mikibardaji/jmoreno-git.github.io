<?php
include "lib/seq_comp.php";
use proven\sequence as seq;
/* 
 * Compares two sequencies and reports number of differences.
 */
$sequence1 = "acgtacgtacgtacgtacgtacgtacgta";
$sequence2 = "acgtacgtacatacgtacgtacgaacgt";
echo "Counting differences between sequencies:" . PHP_EOL;
echo "First sequence: $sequence1" . PHP_EOL;
echo "Second sequence: $sequence2" . PHP_EOL;
try {
    $differences = seq\countDifferences($sequence1, $sequence2);
    echo "Number of differences: $differences" . PHP_EOL; 
} catch (\Exception $ex) {
    echo "Given sequencies differ in length" . PHP_EOL;
}
