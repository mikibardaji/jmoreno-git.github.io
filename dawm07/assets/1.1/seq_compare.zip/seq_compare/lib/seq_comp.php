<?php
namespace proven\sequence;
/**
 * compares two sequencies and count number of non coincident positions.
 * @param string $seq1 firts sequence.
 * @param string $seq2 second sequence.
 * @return int number of non coincident positions.
 * @throws Exception if lengths are different.
 */
function countDifferences(string $seq1, string $seq2): int {
    $counter = 0;
    $length1 = strlen($seq1);
    $length2 = strlen($seq2);
    if ($length1 !== $length2) {
        throw new \Exception("Different lengths");
    }
    for ($i=0; $i<$length1; $i++) {
        if ($seq1[$i] !== $seq2[$i]) {
            $counter++;
        }
    }
    return $counter;
}

