<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Count number of differences between two sequencies</title>
    </head>
    <body>
        <?php
            include "lib/seq_comp.php";
            use proven\sequence as seq;
            /* 
             * Compares two sequencies and reports number of differences.
             */
            $sequence1 = "acgtacgtacgtacgtacgtacgtacgt";
            $sequence2 = "acgtacgtacatacgtacgtacgaacgt";
            echo "<h2>Counting differences between sequencies</h2>";
            echo "<p>First sequence: $sequence1</p>";
            echo "<p>Second sequence: $sequence2</p>";
            try {
                $differences = seq\countDifferences($sequence1, $sequence2);
                echo "<p>Number of differences: $differences</p>"; 
            } catch (\Exception $ex) {
                echo "<p>Given sequencies differ in length</p>";
            }
        ?>
    </body>
</html>
