package cat.proven.clients;

import cat.proven.clients.exceptions.DuplicateException;
import cat.proven.clients.model.Client;
import cat.proven.clients.model.ClientModel;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * ClientManagerAp.java Application to manage a list of clients.
 *
 * @author Jose.
 */
public class ClientManagerAp {

    /**
     * the model data service
     */
    private final ClientModel model;
    /**
     * the menu for the application
     */
    private final ClientMenu mainMenu;

    public ClientManagerAp() {
        model = new ClientModel();
        mainMenu = new ClientMenu();
    }

    public static void main(String args[]) {
        ClientManagerAp ap = new ClientManagerAp();
        ap.run();
    }

    public void run() {
        boolean exit = false;  //flag to exit application.
        String optionSelected;
        //load initial data.
        model.loadClients();
        //control loop
        do {
            mainMenu.show();
            optionSelected = mainMenu.getSelectedOptionActionCommand();
            switch (optionSelected) {
                case "exit": //exit application.
                    exit = true;
                    break;
                case "clientById": //find a client by id.
                    findAClientById();
                    break;
                case "clientAll": //list all clients.
                    listAllClients();
                    break;
                case "clientAdd": //add a new client.
                    addANewClient();
                    break;
                case "clientModify": //modify a client.
                    modifyAClient();
                    break;
                case "clientRemove": //remove a client.
                    removeAClient();
                    break;
                default:
                    System.out.println("Invalid option");
                    break;
            }

        } while (!exit);
        // save final data.
        saveClients();
        System.out.println("Exitting application");
    }

    /**
     * Ask the user for a client id, searches for them in the list
     * and reports result to user.
     */
    private void findAClientById() {
        System.out.println("Searching client...");
        //read the nif
        Scanner sc = new Scanner(System.in);
        System.out.print("Input nif: ");
        String nif = sc.next();
        //search client with given nif
        Client found = model.findClientById(nif);
        if (found != null) {  //client found
            //display client
            System.out.println(found.toString());
        } else {  //client not found
            System.out.println("No client found with nif: "+nif);
        }
    }

    /**
     * Shows the list of all clients.
     */
    private void listAllClients() {
        System.out.println("Listing all clients...");
        List<Client> allClients = model.findAllClients();
        ListIterator<Client> it = allClients.listIterator();
        while (it.hasNext()) {
            Client c = it.next();
            System.out.println(c.toString());
        }
        System.out.format("%d clients found.\n", allClients.size());
    }

    /**
     * Adds a new client to the list. 
     * First, it asks for the new client data to the user, 
     * creates a new client with that data, 
     * and add the new client to the list.
     * Finally, it reports result to user.
     */
    private void addANewClient() {
        System.out.println("Adding a new client...");
        Client cli = readClient();
        if (cli != null) {
            try {
                System.out.println("Adding the new client to the list");
                boolean result = model.addClient(cli);
                String message = result ? "Client successfully added" : "Client not added";
                System.out.println(message);
            } catch (DuplicateException ex) {
                System.out.println("Provided nif already exists in the list");
            }
        } else {
            System.out.println("Client not added. Error in input data");
        }
    }

    /**
     * Modifies a client. 
     * First, it asks the client id, then, it look him up in the list. 
     * If found, it shows the actual client information and ask for new data.
     * Finally, it modifies the client. 
     * If not found, it reports the error to the user.
     */
    private void modifyAClient() {
        System.out.println("Modifying a client...");
        Scanner sc = new Scanner(System.in);
        //read nif
        System.out.print("Input nif: ");
        String nif = sc.next();
        //search client
        Client clientToSearch = model.findClientById(nif);
        if (clientToSearch == null) {  //not found
            System.out.println("No client found with nif: "+nif);
        } else {
            //display client
            System.out.println(clientToSearch);
            //ask for confirmation
            System.out.print("Sure to modify?(Y/N): ");
            String answer = sc.next();
            if (answer.equalsIgnoreCase("Y")) {
                //read client data from user
                Client c = readClient();
                if (c != null) {  try {
                    //if successfully read
                    boolean result = model.modifyClient(clientToSearch, c);
                    if (result) {
                        System.out.println("Client successfully modified");
                    } else {
                        System.out.println("Client not modified");
                    }                     
                    } catch (DuplicateException ex) {
                        System.out.println("Provided nif already exists in the list");
                    }
                }
            }
        }
    }

    /**
     * Removes a client. First, it asks the client id, then, it look him up in
     * the list. If found, it shows the actual client information and ask for
     * confirmation. After comfirmed, it removes the client. If not found, it
     * reports the error to the user.
     */
    private void removeAClient() {
        System.out.println("Removing a client...");
        Scanner sc = new Scanner(System.in);
        //read nif
        System.out.print("Input nif: ");
        String nif = sc.next();
        //search client
        Client clientToSearch = model.findClientById(nif);
        if (clientToSearch == null) {  //not found
            System.out.println("No client found with nif: "+nif);
        } else {
            //display client
            System.out.println(clientToSearch);
            //ask for confirmation
            System.out.print("Sure to remove?(Y/N): ");
            String answer = sc.next();
            if (answer.equalsIgnoreCase("Y")) {
                //remove
                boolean result = model.removeClient(clientToSearch);
                if (result) {
                    System.out.println("Client successfully removed");
                } else {
                    System.out.println("Client not removed");
                }                
            }
        }
    }

    /**
     * readClient() Read from user a client data.
     *
     * @return client object with inputted data or null if an error occurs.
     */
    private Client readClient() {
        System.out.println("Reading client data...");
        Client client = null;
        Scanner sc = new Scanner(System.in);
        try {
            System.out.print("nif: ");
            String nif = sc.next();
            System.out.print("name: ");
            String name = sc.next();
            System.out.print("phone: ");
            String phone = sc.next();
            System.out.print("address: ");
            String address = sc.next();
            System.out.print("amount: ");
            double amount = sc.nextDouble();
            client = new Client(nif, name, phone, address, amount);
        } catch (InputMismatchException e) {
            client = null;
            sc.next();
        }
        return client;
    }

    /**
     * Saves client data to persistent media.
     * Not to be implemented in this release.
     */
    private void saveClients() {
        // TODO
        System.out.println("Saving client list data...");
    }
}
