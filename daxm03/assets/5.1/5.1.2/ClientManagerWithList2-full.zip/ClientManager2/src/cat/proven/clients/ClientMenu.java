package cat.proven.clients;

import cat.proven.menu.Menu;
import cat.proven.menu.MenuItem;

/**
 * Menu for client application
 * @author Jose
 */
public class ClientMenu extends Menu {

    public ClientMenu() {
        title = "Client manager";
        addOption(new MenuItem("Exit", "exit"));
        addOption(new MenuItem("Find a client by id", "clientById"));
        addOption(new MenuItem("List all clients", "clientAll"));
        addOption(new MenuItem("Add a new client", "clientAdd"));
        addOption(new MenuItem("Modify a client", "clientModify"));
        addOption(new MenuItem("Remove a client", "clientRemove"));
    }
    
}
