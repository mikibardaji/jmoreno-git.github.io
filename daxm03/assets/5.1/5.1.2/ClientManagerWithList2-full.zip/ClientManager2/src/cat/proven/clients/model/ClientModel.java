package cat.proven.clients.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Model Data service for client application
 * @author Jose
 */
public class ClientModel {

    /**
     * holds the list of clients
     */
    private final List<Client> clients;

    public ClientModel() {
        this.clients = new ArrayList<>();
    }

    public List<Client> findAllClients() {
        return new ArrayList<>(clients); //better copy list
        //return clients;
    }

    /**
     * finds a client with given nif
     *
     * @param nif the 'nif' value to search
     * @return a client with the given nif or null if not found
     */
    public Client findClientById(String nif) {
        Client found = null;
        Client c = new Client(nif);
        int index = clients.indexOf(c);
        if (index >= 0) { //found
            found = clients.get(index);
        }
        return found;
    }

    /**
     * adds a new client to the list. It prevents null objects and duplicates
     *
     * @param client tle element to add
     * @return true if successfully added, false otherwise
     */
    public boolean addClient(Client client) {
        boolean b = false;
        if (client != null) {  //assess client is not null
            if (!clients.contains(client)) { // assess client not in list
                b = clients.add(client);
            }
        }
        return b;
    }

    /**
     * removes a client from the list.
     *
     * @param client the client to remove
     * @return true is successfully removed, false otherwise.
     */
    public boolean removeClient(Client client) {
        boolean b = false;
        if (client != null) {
            b = clients.remove(client);
        }
        return b;
    }

    /**
     * modifies client 'current' with data in 'c'
     * It prevents null objects and nif duplicates
     * @param current the current client to be replaced
     * @param c the new value to replace
     * @return true is successfully modified, false otherwise.
     */
    public boolean modifyClient(Client current, Client c) {
        boolean b = false;
        if (c != null) {  //avoid setting null objects
            if (!clients.contains(c)) { //avoid setting objects with existing if
                //search 'current' in list
                int index = clients.indexOf(current);
                if (index >= 0) {  //found
                    clients.set(index, c);
                    b = true;
                }
            }
        }
        return b;
    }

    /**
     * Loads initial data into client list.
     */
    public void loadClients() {
        System.out.println("Loading client data into list of clients...");
        addClient(new Client("001A", "Peter", "93001", "Addr01", 1001.0));
        addClient(new Client("001B", "Paul", "93002", "Addr02", 1002.0));
        addClient(new Client("001C", "Mary", "93003", "Addr03", 1003.0));
        addClient(new Client("001D", "Bob", "93004", "Addr04", 1004.0));
        addClient(new Client("001E", "Sophie", "93005", "Addr05", 1005.0));
        addClient(new Client("001F", "Andrew", "93006", "Addr06", 1006.0));
        addClient(new Client("001G", "Phil", "93007", "Addr07", 1007.0));
    }

}
