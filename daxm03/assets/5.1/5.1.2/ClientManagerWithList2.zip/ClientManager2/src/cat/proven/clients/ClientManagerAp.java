package cat.proven.clients;

import cat.proven.clients.model.Client;
import cat.proven.clients.model.ClientModel;
import java.util.*;

/**
 * ClientManagerAp.java Application to manage a list of clients.
 *
 * @author Jose.
 */
public class ClientManagerAp {

    private final ClientModel model;
    private final ClientMenu mainMenu;

    public ClientManagerAp() {
        model = new ClientModel();
        mainMenu = new ClientMenu();
    }

    public static void main(String args[]) {
        ClientManagerAp ap = new ClientManagerAp();
        ap.run();
    }

    public void run() {
        boolean exit = false;  //flag to exit application.
        String optionSelected;
        // load initial data.
        model.loadClients();
        //control loop
        do {
            optionSelected = mainMenu.getSelectedOptionActionCommand();
            switch (optionSelected) {
                case "exit": //exit application.
                    exit = true;
                    break;
                case "clientById": //find a client by id.
                    findAClientById();
                    break;
                case "clientAll": //list all clients.
                    listAllClients();
                    break;
                case "clientAdd": //add a new client.
                    addANewClient();
                    break;
                case "clientModify": //modify a client.
                    modifyAClient();
                    break;
                case "clientRemove": //remove a client.
                    removeAClient();
                    break;
                default:
                    System.out.println("Invalid option");
                    break;
            }

        } while (!exit);

        // save final data.
        saveClients();
        System.out.println("Exitting application");

    }

    /**
     * Ask the user for a client id and searches for him in the list.
     */
    private void findAClientById() {
        // TODO
        System.out.println("Searching client...");
    }

    /**
     * Shows the list of clients.
     */
    private void listAllClients() {
        System.out.println("Listing all clients...");
        List<Client> allClients = model.findAllClients();
        ListIterator<Client> it = allClients.listIterator();
        while (it.hasNext()) {
            Client c = it.next();
            System.out.println(c.toString());
        }
        System.out.format("%d clients found.\n", allClients.size());
    }

    /**
     * Adds a new client to the list. First, it asks for the new client data to
     * the user, creates a new client with that data, and add the new client to
     * the list.
     */
    private void addANewClient() {
        System.out.println("Adding a new client...");
        Client cli = readClient();
        if (cli != null) {
            System.out.println("Adding the new client to the list");
            boolean result = model.addClient(cli);
            String message = result ? "Client successfully added" : "Client not added";
            System.out.println(message);
        } else {
            System.out.println("Client not added. Error in input data");
        }
    }

    /**
     * Modifies a client. First, it asks the client id, then, it look him up in
     * the list. If found, it shows the actual client information and ask for
     * new data. Finally, it modifies the client. If not found, it reports the
     * error to the user.
     */
    private void modifyAClient() {
        // TODO
        System.out.println("Modifying a client...");
    }

    /**
     * Removes a client. First, it asks the client id, then, it look him up in
     * the list. If found, it shows the actual client information and ask for
     * confirmation. After comfirmed, it removes the client. If not found, it
     * reports the error to the user.
     */
    private void removeAClient() {
        // TODO
        System.out.println("Removing a client...");
    }

    /**
     * readClient() Read from user a client data.
     *
     * @return client object with inputted data or null if an error occurs.
     */
    private Client readClient() {
        // TODO
        System.out.println("Reading client data...");
        return null;
        //return new Client();
    }

    /**
     * Saves client data to persistent media.
     */
    private void saveClients() {
        // TODO
        System.out.println("Saving client list data...");
    }
}
