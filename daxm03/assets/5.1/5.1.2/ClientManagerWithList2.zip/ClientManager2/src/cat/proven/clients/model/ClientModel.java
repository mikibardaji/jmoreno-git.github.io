package cat.proven.clients.model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Jose
 */
public class ClientModel {
    private final List<Client> clients;

    public ClientModel() {
        this.clients = new ArrayList<>();
    }
    
    public List<Client> findAllClients() {
        return new ArrayList<>(clients);
    }
    
    public boolean addClient(Client client) {
        return clients.add(client);
    }

    /**
     * Loads initial data into client list.
     */
    public void loadClients() {
        System.out.println("Loading client data into list of clients...");
        addClient(new Client("001A", "Peter", "93001", "Addr01", 1001.0));
        addClient(new Client("001B", "Paul", "93002", "Addr02", 1002.0));
        addClient(new Client("001C", "Mary", "93003", "Addr03", 1003.0));
        addClient(new Client("001D", "Bob", "93004", "Addr04", 1004.0));
        addClient(new Client("001E", "Sophie", "93005", "Addr05", 1005.0));
        addClient(new Client("001F", "Andrew", "93006", "Addr06", 1006.0));
        addClient(new Client("001G", "Phil", "93007", "Addr07", 1007.0));
    }
    
}
