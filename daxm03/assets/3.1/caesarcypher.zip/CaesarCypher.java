package iostream;

/**
 * Shift (Caesar's) cyphering on single character
 * @author Jose
 */
public class CaesarCypher {
    
    /**
     * alphabet for character conversion
     */
    private final String letters = "abcdefghijklmnñopqrstuvwxyz0123456789áéèíóòúï !$%&-/#@&()=¿?¡+*.:,;_";
    
    /**
     * cyphers character with Caesar's shift algorithm
     * @param c the character to encrypt
     * @param shift the shift to apply
     * @return cyphered character
     */
    public char encrypt(char c, int shift) {
        char result=' ';
        if (shift < 0) {
            shift = -shift;
        }
        shift %= letters.length();
        int index = letters.indexOf(c);
        if (index >= 0) {  //found
            int shiftedIndex = index+shift;
            if (shiftedIndex >= letters.length()) {
                shiftedIndex -= letters.length();
            }
            result = letters.charAt(shiftedIndex);
        }
        return result;
    }

    /**
     * decyphers character with Caesar's shift algorithm
     * @param c the character to decrypt
     * @param shift the shift to apply
     * @return decyphered character
     */    
    public char decrypt(char c, int shift) {
        char result=' ';
        if (shift < 0) {
            shift = -shift;
        }
        shift %= letters.length();
        int index = letters.indexOf(c);
        if (index >= 0) {  //found
            int shiftedIndex = index-shift;
            if (shiftedIndex < 0) {
                shiftedIndex += letters.length();
            }
            result = letters.charAt(shiftedIndex);
        }
        return result;
    }
}
