package iostream;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author Jose
 */
public class CypherFileMain {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        //ask choice
        System.out.print("Cypher or decypher? (C/D): ");
        String option = sc.next();
        //ask source file
        System.out.print("Origin file: ");
        String originFile = sc.next();
        //ask destination file
        System.out.print("Target file: ");
        String targetFile = sc.next();
        //ask shift to apply
        System.out.print("Shift: ");
        int shift = sc.nextInt();
        //get a file cypher object
        FileCypher cypher = new FileCypher();
        //execute action
        char action = option.toLowerCase().charAt(0);
        String message="";
        try {
            switch (action) {
                case 'c':
                    cypher.cypherFile(originFile, targetFile, shift);
                    message = String.format("'%s' file transformed into '%s' file", 
                            originFile, targetFile);
                    break;
                case 'd':
                    cypher.decypherFile(originFile, targetFile, shift);
                    message = String.format("'%s' file transformed into '%s' file", 
                            originFile, targetFile);
                    break;
                default:
                    message = "Not a valid choice";
            }
            System.out.println(message);
        } catch (FileNotFoundException ex) {
            System.out.format("File %s not found.\n", originFile);
        }
        catch (IOException ex) {
            System.out.println("Input/output error: "+ex.getMessage());
        }
    }
    
}
