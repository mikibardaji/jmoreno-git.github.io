
package iostream;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Encrypting of a whole text file using Caesar's shift algorithm
 * @author Jose
 */
public class FileCypher {
    
    /**
     * Cyphering service object for a single character
     */
    private final CaesarCypher cypher;

    public FileCypher() {
        cypher = new CaesarCypher();
    }
    
    /**
     * reads text from a file and writes to another after cyphering
     * @param origin the name of the source file
     * @param target the name of the destination file
     * @param shift the integer shift to apply on cyphering
     * @throws FileNotFoundException if origin file is not found
     * @throws IOException if some input/output error occurs
     */
    public void cypherFile(String origin, String target, int shift) 
            throws FileNotFoundException, IOException {
        try (FileReader in = new FileReader(origin); 
             FileWriter out = new FileWriter(target)) {
            int ic;
            while ( (ic=in.read()) != -1 ) {
                char originC = Character.toLowerCase((char) ic);
                char targetC = cypher.encrypt(originC, shift);
                out.write(targetC);
            }
        }
    }

    /**
     * reads text from a file and writes to another after decyphering
     * @param origin the name of the source file
     * @param target the name of the destination file
     * @param shift the integer shift to apply on decyphering
     * @throws FileNotFoundException if origin file is not found
     * @throws IOException if some input/output error occurs
     */    
    public void decypherFile(String origin, String target, int shift) 
            throws FileNotFoundException, IOException {
        try (FileReader in = new FileReader(origin); 
             FileWriter out = new FileWriter(target)) {
            int ic;
            while ( (ic=in.read()) != -1 ) {
                char originC = Character.toLowerCase((char) ic);
                char targetC = cypher.decrypt(originC, shift);
                out.write(targetC);
            }
        }
    }
}
