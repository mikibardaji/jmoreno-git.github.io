
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Jose
 */
public class BmiPanel extends JPanel implements ActionListener {
    
    private Bmi model;
    
    private JTextField tfWeight;
    private JTextField tfHeight;
    private JTextField tfBmi;

    private ActionListener listener;
    
    public BmiPanel() {
        model = new Bmi();
        listener = this;
        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout());
        //create header label
        JLabel lbHeader = new JLabel("BMI calculation form");
        add(lbHeader, BorderLayout.NORTH);
        //create calculation form
        JPanel form = createBmiForm();
        add(form, BorderLayout.CENTER);
    }
    
    private JPanel createBmiForm() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(0,2));
        //
        panel.add(new JLabel("Weight:"));
        tfWeight = new JTextField(20);
        panel.add(tfWeight);
        //
        panel.add(new JLabel("Height:"));
        tfHeight = new JTextField(20);
        panel.add(tfHeight);
        //
        JButton btClear = new JButton("Clear");
        btClear.setActionCommand("clear");
        btClear.addActionListener(listener);
        panel.add(btClear);
        JButton btCalc = new JButton("Calculate");
        btCalc.setActionCommand("calculate");
        btCalc.addActionListener(listener);
        panel.add(btCalc);
        //
        panel.add(new JLabel("Body mass index:"));
        tfBmi = new JTextField(20);
        tfBmi.setEditable(false);
        panel.add(tfBmi);
        //
        return panel;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String actionCommand = e.getActionCommand();
        System.out.println("Executing action: "+actionCommand);
    }
}
