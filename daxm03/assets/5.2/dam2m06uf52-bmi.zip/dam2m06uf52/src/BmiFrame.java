
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

/**
 *
 * @author Jose
 */
public class BmiFrame extends JFrame implements ActionListener {
    
    private BmiPanel bmiPanel;
    
    private ActionListener listener;

    public BmiFrame() {
        listener = this;
        initComponents();
    }
    
    private void initComponents() {
        //set default close operation when close button is clicked
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //configure menu bar
        setUpMenu();
        //display bmi panel
        displayBmiPanel();
        //set window size
        setSize(400, 300);
    }

    private void setUpMenu() {
        JMenuBar menuBar = new JMenuBar();
        JMenu menu;
        JMenuItem menuItem;
        //
        menu = new JMenu("File");
            //
            menuItem = new JMenuItem("Exit");
            menuItem.setActionCommand("exit");
            menuItem.addActionListener(listener);
            menu.add(menuItem);
            //
        menuBar.add(menu);
        //
        menu = new JMenu("Help");
            //
            menuItem = new JMenuItem("About");
            menuItem.setActionCommand("about");
            menuItem.addActionListener(listener);
            menu.add(menuItem);
            //
        menuBar.add(menu);
        //
        setJMenuBar(menuBar);
    }

    private void displayBmiPanel() {
        bmiPanel = new BmiPanel();
        setContentPane(bmiPanel);
        validate();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String actionCommand = e.getActionCommand();
        System.out.println("Executing action: "+actionCommand);
    }
    
}
