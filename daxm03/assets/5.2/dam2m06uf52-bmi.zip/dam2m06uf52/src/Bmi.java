/**
 *
 * @author Jose
 */
public class Bmi {
    public double bmiCalc(double height, double weight) {
        return weight / (height * height);
    }
}
