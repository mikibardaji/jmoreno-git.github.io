
import javax.swing.SwingUtilities;

/**
 *
 * @author Jose
 */
public class BmiMain {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                BmiFrame mainFrame = new BmiFrame();
                mainFrame.setVisible(true);
            }
        });
    }
    
}
