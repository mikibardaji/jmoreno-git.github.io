
import java.util.Random;
import java.util.Scanner;

/**
 * Joc de pedra, paper i tissores, versió programació estructurada i modular,
 * sense objectes ni atributs de classe.
 * @author jose
 */
public class PedraPaperTissoresJoc {

    public static void main(String[] args) {
        PedraPaperTissoresJoc joc = new PedraPaperTissoresJoc();
        joc.iniciaJoc();
    }

    public void iniciaJoc() {
        String titol = "============='Pedra, paper, tissores', per ProvenSoft=============";
        System.out.println(titol);
        //llegir tirades a guanyar per acabar
        int minPuntsGuanyar = 3;  //TODO: llegir de l'usuari
        //llegir tirades màximes a jugar
        int maxTirades = 6;   //TODO: llegir de l'usuari
        //inicialitzar variables del joc
        int numTirades = 0;  //número de tirades efectuades
        int puntsJugador = 0;  //punts del jugador 1
        int puntsOrdinador = 0;  //punts de l'ordinador
        //iniciar el joc
        boolean continuar = true;  //senyal per continuar o finalitzar el joc
        do {
            //tirada jugador
            int tiradaJugador = jugarJugador();
            //tirada ordinador
            int tiradaOrdinador = jugarOrdinador();
            //mostrar les tirades
            System.out.format("Tirada %d> jugador-ordinador: %d-%d\t",
                    numTirades, tiradaJugador, tiradaOrdinador);
            //verificar guanyador
            int guanyador = quiGuanya(tiradaJugador, tiradaOrdinador);
            //actualitzar comptadors
            numTirades++;  //incrementar nombre de tirades
            switch (guanyador) {
                case 0: //empat, no fer res
                    System.out.println("Empat");
                    break;
                case 1: //guanya jugador
                    puntsJugador++;  //incrementar punts jugador
                    System.out.println("Tú guanyes!");
                    break;
                case 2: //guanya ordinador
                    puntsOrdinador++;  //incrementar punts ordinador
                    System.out.println("L'ordinador guanya");
                    break;
            }
            //comprovar si s'acaba el joc
            continuar = (numTirades<maxTirades)
                    && (Math.max(puntsJugador, puntsOrdinador)<minPuntsGuanyar);
            //mostrar marcadors actuals
            mostrarMarcadors(numTirades, puntsJugador, puntsOrdinador);
        } while (continuar);
        //mostrar resultat final del joc
        String resultat;  //el resultat final del joc
        if (puntsJugador==puntsOrdinador) {
            resultat = "empat";
        } else {
            resultat = (puntsJugador>puntsOrdinador) ? "Has guanyat" : "Ha guanyat l'ordinador";
        }
        System.out.println("***"+resultat.toUpperCase()+"***");
        System.out.println("Gràcies per jugar al nostre joc! T'hi esperem aviat!");
    }

    /**
     * llegeix de l'usuari la jugada
     * @return la jugada del jugador
     */
    public int jugarJugador() {
        Scanner lector = new Scanner(System.in);
        System.out.print("Pedra (0), Paper (1), Tissores (2)? ");
        int tirada = lector.nextInt();
        while ( (tirada<0) || (tirada>2) ) {
            System.out.print("Selecció no vàlida. Torna a provar. ");
            tirada = lector.nextInt();
        }
        return tirada;
    }

    /**
     * genera aleatòriament la jugada de l'ordinador
     * @return la jugada de l'ordiandor
     */
    public int jugarOrdinador() {
        Random rnd = new Random();
        return rnd.nextInt(0, 3);
    }

    /**
     * determina el guanyador d'una tirada
     * @param tiradaJugador la tirada del jugador
     * @param tiradaOrdinador la tirada de l'ordinador
     * @return el número del jugador que guanya (1: usuari, 2: ordinador) o bé 0 en cas d'empat
     */
    public int quiGuanya(int tiradaJugador, int tiradaOrdinador) {
        int result = 0;
        if (tiradaJugador == tiradaOrdinador) {
            result = 0;  //empat
        } else {
            switch (tiradaJugador) {
                case 0:
                    result = (tiradaOrdinador==2) ? 1 : 2;
                    break;
                case 1:
                    result = (tiradaOrdinador==0) ? 1 : 2;
                    break;
                case 2:
                    result = (tiradaOrdinador==1) ? 1 : 2;
                    break;
            }
        }
        return result;
    }

    /**
     * mostra els marcadors de punts
     * @param numTirades el nombre de tirades actual
     * @param puntsJugador els punts del jugador (usuari)
     * @param puntsOrdinador els punts de l'ordinador
     */
    public void mostrarMarcadors(int numTirades, int puntsJugador, int puntsOrdinador) {
        System.out.format("Tirada %d> \t Punts Jugador: %d \t Punts ordinador: %d\n",
                numTirades, puntsJugador, puntsOrdinador);
    }
    
}
